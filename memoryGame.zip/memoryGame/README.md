#My Memory Game#

##This is a Guide for use of my Memory game##

###Directions:-###

In This game, You ope  **two** cards in one step... If They were similar They remain faced up, If no , The will be faced down again.

The game ends when **All** cards are faced up.

You can reset the game with the **restart** button.

You can pause the timer with the **pause** button.

You can chane the level of the game and chose to play in either :
1- Easy: have **16** cards.

2- Moderate: have **36** cards.

3-Hard: have **64** cards.

The highest Scores Are recorded for the top **10** scores.

The highest score is one has ended the game with the **greater** number of stars.

if stars were equal The scores are recoreded with the **least** number of moves.

if moves were equal The scored are recorded with the **smallest** time amount.

A Star is lost after **12** Moves.

You also can Control The game with the keybord:

1- Use the direction arrows to move across cards and use the **enter** button to open them.

2- use the **r** buttoon to restart the game.

3- use the **p** button to pause the game.

4- use the **h** button to view the highest scores.

5- use the **c** button to change the level

Can be played in _All_ Devices... **iphone**, **ipad**, **galaxy**, **laptops**.